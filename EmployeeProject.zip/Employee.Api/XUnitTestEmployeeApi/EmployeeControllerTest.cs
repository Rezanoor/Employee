using EmployeeApi.Controllers;
using EmployeeApi.Models;
using EmployeeApi.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace XUnitTestEmployeeApi
{
    public class EmployeeControllerTest
    {
        
        EmployeeController _controller;
        IEmployeeService _service;

        public EmployeeControllerTest()
        {
            _service = new EmployeeService();
            _controller = new EmployeeController(_service);
            Environment.SetEnvironmentVariable("DATA_SOURCE", "Data/MOCK_DATA_SML.json");
        }

        [Fact]
        public async Task GetAllEmployeeAsync()
        {
            //arrange
            //act
            var result = await _controller.Get();

            //assert
            Assert.IsType<OkObjectResult>(result.Result);

            var list = result.Result as OkObjectResult;
            Assert.IsType<List<EmployeeModel>>(list.Value);

            var listEmployees = list.Value as List<EmployeeModel>;
            Assert.NotEmpty(listEmployees);

        }

        [Theory]
        [InlineData(1, 14)]
        public void GetEmployeeIdTest(long id1, long id2)
        {
            //arrange
            var invalidId = id1;
            var validId = id2;
            //act
            var notFoudnResult = _controller.Get(invalidId);
            var okResult = _controller.Get(validId);
            //assert
            Assert.IsType<NotFoundResult>(notFoudnResult.Result);

            Assert.IsType<ObjectResult>(okResult.Result);

            var item = okResult.Result as OkObjectResult;
            Assert.IsType<EmployeeModel>(item.Value);

            var Employeetem = item.Value as EmployeeModel;
            Assert.Equal(validId, Employeetem.id);
            Assert.Equal("Title", Employeetem.email);
        }

        [Fact]
        public void AddEmployeeTest()
        {
            //arrange
            var completEmployee = new EmployeeModel()
            {
                id = 1,
                firstName = "reza",
                lastName = "nourbakhsh",
                email = "reza.nourbakhsh@ymail.com",
                gender = Gender.Male,
                status = true
            };
            //act
            var createdResponse = _controller.Create(completEmployee);
            //Assert
            Assert.IsType<CreatedAtActionResult>(createdResponse);

            var item = createdResponse as CreatedAtActionResult;
            Assert.IsType<EmployeeModel>(item.Value);

            var employeeItem = item.Value as EmployeeModel;
            Assert.Equal(completEmployee.id, employeeItem.id);
            Assert.Equal(completEmployee.firstName, employeeItem.firstName);
            Assert.Equal(completEmployee.lastName, employeeItem.lastName);

            //arrange
            var incompletEmployee = new EmployeeModel()
            {
                id = 1,
                email = "email"
            };
            //act
            _controller.ModelState.AddModelError("email", "email is required field");
            var badResponse = _controller.Create(incompletEmployee);
            //assert
            Assert.IsType<BadRequestObjectResult>(badResponse);
        }

        [Theory]
        [InlineData(1, 14)]
        public async System.Threading.Tasks.Task RemoveEmployeeByIdAsync(long id1, long id2)
        {
            //arrange
            var validId = id1;
            var invalidId = id2;
            //act
            var notFoudnResult = _controller.Remove(invalidId);

            //assert
            Assert.IsType<NotFoundResult>(notFoudnResult);
            var employeesBad = await _service.GetAllAsync();
            Assert.Equal(5, employeesBad.employees.Count());

            //act
            var okResult = _controller.Remove(validId);

            //assert
            Assert.IsType<ObjectResult>(okResult);
            var employeesOk = await _service.GetAllAsync();
            Assert.Equal(4, employeesOk.employees.Count());
        }
    }
}
