﻿
using Employee.Api.Models;
using EmployeeApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EmployeeApi.Services
{
    public interface IEmployeeService
    {
        Task<EmployeeListModel> GetAllAsync();
        EmployeeModel Create(EmployeeModel employee);
        EmployeeModel Update(EmployeeModel employee);
        EmployeeModel GetById(long id);
        void Remove(long id);
    }
}
