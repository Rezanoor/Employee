﻿using EmployeeApi.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee.Api.Models
{
    
    public class EmployeeListModel
    {
        [JsonProperty("employees")]
        [BindProperty(Name = "employees")]
        [System.Text.Json.Serialization.JsonPropertyName("employees")]
        public List<EmployeeModel> employees { get; set; }
    }
}
