﻿

using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel.DataAnnotations;

namespace EmployeeApi.Models
{
    public class EmployeeModel
    {
        [JsonProperty("id")]
        public long id { get; set; }

        [BindProperty(Name = "first_name")]
        [JsonProperty(PropertyName = "first_name")]
        [System.Text.Json.Serialization.JsonPropertyName("first_name")]
        public string firstName { get; set; }
        
        [JsonProperty("last_name")]
        [BindProperty(Name = "last_name")]
        [System.Text.Json.Serialization.JsonPropertyName("last_name")]
        public string lastName { get; set; }
        
        [JsonProperty("email")]
        [Required]
        public string email { get; set; }
        
        [JsonProperty("gender")]
        [JsonConverter(typeof(StringEnumConverter))]
        public Gender gender { get; set; }
        
        [JsonProperty("status")]
        public bool status { get; set; }
    }

    public enum Gender
    {
        Male,
        Female,
        Other
    }
}
