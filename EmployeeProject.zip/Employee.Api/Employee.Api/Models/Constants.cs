﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee.Api.Models
{
    public class Constants
    {
        public const string DATA_SOURCE = "DATA_SOURCE";
        public const string ALLOW_ORIGIN_URL = "ALLOW_ORIGIN";
        public const string MyAllowSpecificOrigins = "_myAllowSpecificOrigins";
    }
}
