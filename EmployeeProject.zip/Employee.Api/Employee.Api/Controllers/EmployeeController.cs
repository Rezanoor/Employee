﻿using System;
using System.Collections.Generic;
using EmployeeApi.Services;
using Microsoft.AspNetCore.Mvc;
using EmployeeApi.Models;
using System.Threading.Tasks;
using Employee.Api.Models;
using Microsoft.AspNetCore.Cors;

namespace EmployeeApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeService _service;

        public EmployeeController(IEmployeeService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<EmployeeListModel>> Get()
        {
            var items = await _service.GetAllAsync();
            return Ok(items.employees);

        }

        [HttpGet("{id}")]
        public ActionResult<EmployeeModel> Get(long id)
        {
            var item = _service.GetById(id);

            if (item == null)
            {
                return NotFound();
            }

            return Ok(item);
        }

        [HttpPost]
        public ActionResult Create([FromBody] EmployeeModel employee)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var item = _service.Create(employee);
            return CreatedAtAction("Get", new { id = item.id }, item);
        }

        [HttpPut]
        public ActionResult Update([FromBody] EmployeeModel employee)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var item = _service.Update(employee);
            return CreatedAtAction("Get", new { id = item.id }, item);
        }

        [HttpDelete("{id}")]
        public ActionResult Remove(long id)
        {
            var itemToRemove = _service.GetById(id);

            if (itemToRemove == null)
            {
                return NotFound();
            }

            _service.Remove(id);
            return Ok(itemToRemove);
        }

    }
}
