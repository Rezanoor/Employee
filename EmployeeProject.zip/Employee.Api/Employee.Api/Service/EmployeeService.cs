﻿using Employee.Api.Models;
using EmployeeApi.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeApi.Services
{
    public class EmployeeService : IEmployeeService
    {
        private static List<EmployeeModel> _employees = null;
        public EmployeeService()
        {
            if(_employees == null)
            {
                _employees = new List<EmployeeModel>();
            }
        }

        public async Task<EmployeeListModel> GetAllAsync()
        {
            //TODO: this shouldn't really be here. It must be in a repository class
            //TODO is implementing a repository pattern and move it there
            if (!_employees.Any()) {
                 using (StreamReader streamReader = new StreamReader(Environment.GetEnvironmentVariable(Constants.DATA_SOURCE)))
                {
                    string json = await streamReader.ReadToEndAsync();
                    _employees = JsonConvert.DeserializeObject<List<EmployeeModel>>(json);
                }
            }
            EmployeeListModel employees = new EmployeeListModel();
            employees.employees = new List<EmployeeModel>();
            employees.employees.AddRange(_employees);
            return employees;
        }

        public EmployeeModel GetById(long id)
        {
            if(_employees != null || !_employees.Any())
            {
                return _employees.Find(e => e.id == id);
            }
            else
            {
                return new EmployeeModel();
            }
        }

        public EmployeeModel Create(EmployeeModel employee)
        {

            long maxId = _employees.Select(e => e.id).Max();
            employee.id = maxId++; 
            _employees.Add(employee);
            
            return employee;
        }

        public EmployeeModel Update(EmployeeModel employee)
        {
            var employeeToSave = GetById(employee.id);

            if (employeeToSave != null)
            {
                employeeToSave.firstName = employee.firstName;
                employeeToSave.lastName = employee.lastName;
                employeeToSave.email = employee.email;
                employeeToSave.gender = employee.gender;
                employeeToSave.status = employee.status;
            }

            return employee;
        }

        public void Remove(long id)
        {
            var employee = _employees.Find(e => e.id == id);
            if (employee != null)
            {
                _employees.Remove(employee);
            }
        }
    }
}
