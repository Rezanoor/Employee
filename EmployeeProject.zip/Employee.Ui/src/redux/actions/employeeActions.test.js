import * as employeeActions from "./employeeActions";
import * as types from "./actionTypes";
import { employees } from "../../../tools/mockData";
import thunk from "redux-thunk";
import fetchMock from "fetch-mock";
import configureMockStore from "redux-mock-store";

// Test an async action
const middleware = [thunk];
const mockStore = configureMockStore(middleware);

describe("Async Actions", () => {
  afterEach(() => {
    fetchMock.restore();
  });

  describe("Load Employees Thunk", () => {
    it("should create BEGIN_API_CALL and LOAD_EMPLOYEES_SUCCESS when loading employees", () => {
      fetchMock.mock("*", {
        body: employees,
        headers: { "content-type": "application/json" }
      });

      const expectedActions = [
        { type: types.BEGIN_API_CALL },
        { type: types.LOAD_EMPLOYEES_SUCCESS, employees }
      ];

      const store = mockStore({ employees: [] });
      return store.dispatch(employeeActions.loadEmployees()).then(() => {
        expect(store.getActions()).toEqual(expectedActions);
      });
    });
  });
});

describe("createEmployeeSuccess", () => {
  it("should create a CREATE_EMPLOYEE_SUCCESS action", () => {
    //arrange
    const employee = employees[0];
    const expectedAction = {
      type: types.CREATE_EMPLOYEE_SUCCESS,
      employee
    };

    //act
    const action = employeeActions.createEmployeeSuccess(employee);

    //assert
    expect(action).toEqual(expectedAction);
  });
});
