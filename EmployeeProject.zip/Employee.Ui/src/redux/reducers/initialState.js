export default {
  employees: [],
  apiCallsInProgress: 0
};
