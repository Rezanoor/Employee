import employeeReducer from "./employeeReducer";
import * as actions from "../actions/employeeActions";

it("should add employee when passed CREATE_EMPLOYEE_SUCCESS", () => {
  // arrange
  const initialState = [
    {
      first_name: "A"
    },
    {
      first_name: "B"
    }
  ];

  const newEmployee = {
    first_name: "C"
  };

  const action = actions.createEmployeeSuccess(newEmployee);

  // act
  const newState = employeeReducer(initialState, action);

  // assert
  expect(newState.length).toEqual(3);
  expect(newState[0].first_name).toEqual("A");
  expect(newState[1].first_name).toEqual("B");
  expect(newState[2].first_name).toEqual("C");
});

it("should update employee when passed UPDATE_EMPLOYEE_SUCCESS", () => {
  // arrange
  const initialState = [
    { id: 1, first_name: "A" },
    { id: 2, first_name: "B" },
    { id: 3, first_name: "C" }
  ];

  const employee = { id: 2, first_name: "New Name" };
  const action = actions.updateEmployeeSuccess(employee);

  // act
  const newState = employeeReducer(initialState, action);
  const updatedEmployee = newState.find(a => a.id == employee.id);
  const untouchedEmployee = newState.find(a => a.id == 1);

  // assert
  expect(updatedEmployee.first_name).toEqual("New Name");
  expect(untouchedEmployee.first_name).toEqual("A");
  expect(newState.length).toEqual(3);
});
