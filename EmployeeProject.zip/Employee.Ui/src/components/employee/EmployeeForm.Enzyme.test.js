import React from "react";
import EmployeeForm from "./EmployeeForm";
import { shallow } from "enzyme";

function renderEmployeeForm(args) {
  const defaultProps = {
    employee: {},
    saving: false,
    errors: {},
    onSave: () => {},
    onChange: () => {}
  };

  const props = { ...defaultProps, ...args };
  return shallow(<EmployeeForm {...props} />);
}

it("renders form and header", () => {
  const wrapper = renderEmployeeForm();
  // console.log(wrapper.debug());
  expect(wrapper.find("form").length).toBe(1);
  expect(wrapper.find("h2").text()).toEqual("Add Employee");
});

it('labels save buttons as "Save" when not saving', () => {
  const wrapper = renderEmployeeForm();
  expect(wrapper.find("button").text()).toBe("Save");
});

it('labels save button as "Saving..." when saving', () => {
  const wrapper = renderEmployeeForm({ saving: true });
  expect(wrapper.find("button").text()).toBe("Saving...");
});
