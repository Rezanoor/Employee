import React from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";

const EmployeeList = ({ employees, onDeleteClick }) => (
  <table className="table">
    <thead>
      <tr>

        <th>FirstName</th>
        <th>LastName</th>
        <th>Email</th>
        <th>Gender</th>
        <th>Status</th>

      </tr>
    </thead>
    <tbody>
      {employees.map(employee => {
        return (
          <tr key={employee.id}>
            
            <td>
              <Link to={"/employee/" + employee.id}>{employee.first_name}</Link>
            </td>
            <td>{employee.last_name}</td>
            <td>{employee.email}</td>
            <td>{employee.gender}</td>
            <td> {employee.status ? "Active" : "Inactive"}</td>
            <td>
              <button
                className="btn btn-outline-danger"
                onClick={() => onDeleteClick(employee)}
              >
                Delete
              </button>
            </td>
          </tr>
        );
      })}
    </tbody>
  </table>
);

EmployeeList.propTypes = {
  employees: PropTypes.array.isRequired,
  onDeleteClick: PropTypes.func.isRequired
};

export default EmployeeList;
