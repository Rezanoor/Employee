import React from "react";
import { connect } from "react-redux";
import * as employeeActions from "../../redux/actions/employeeActions";
import PropTypes from "prop-types";
import { bindActionCreators } from "redux";
import EmployeeList from "./EmployeeList";
import { Redirect } from "react-router-dom";
import Spinner from "../common/Spinner";
import { toast } from "react-toastify";

class EmployeesPage extends React.Component {
  state = {
    redirectToAddEmployeePage: false
  };

  componentDidMount() {
    const { employees, actions } = this.props;

    if (employees.length === 0) {
      actions.loadEmployees().catch(error => {
        alert("Loading employees failed" + error);
      });
    }

  }

  handleDeleteEmployee = async employee => {
    toast.success("Employee deleted");
    try {
      debugger;
      await this.props.actions.deleteEmployee(employee);
    } catch (error) {
      toast.error("Delete failed. " + error.message, { autoClose: false });
    }
  };

  render() {
    return (
      <>
        {this.state.redirectToAddEmployeePage && <Redirect to="/employee" />}
        <h2>Employees</h2>
        {this.props.loading ? (
          <Spinner />
        ) : (
          <>
            <button
              style={{ marginBottom: 20 }}
              className="btn btn-primary add-employee"
              onClick={() => this.setState({ redirectToAddEmployeePage: true })}
            >
              Add Employee
            </button>

            <EmployeeList
              onDeleteClick={this.handleDeleteEmployee}
              employees={this.props.employees}
            />
          </>
        )}
      </>
    );
  }
}

EmployeesPage.propTypes = {
  employees: PropTypes.array.isRequired,
  actions: PropTypes.object.isRequired,
  loading: PropTypes.bool.isRequired
};

function mapStateToProps(state) {
  return {
    employees: state.employees,
    loading: state.apiCallsInProgress > 0
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: {
      loadEmployees: bindActionCreators(employeeActions.loadEmployees, dispatch),
      deleteEmployee: bindActionCreators(employeeActions.deleteEmployee, dispatch)
    }
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(EmployeesPage);
