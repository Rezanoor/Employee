import React from "react";
import PropTypes from "prop-types";
import TextInput from "../common/TextInput";
import SelectInput from "../common/SelectInput";

const EmployeeForm = ({
  employee,
  onSave,
  onChange,
  saving = false,
  errors = {}
}) => {
  return (
    <form onSubmit={onSave}>
      <h2>{employee.id ? "Edit" : "Add"} Employee</h2>
      {errors.onSave && (
        <div className="alert alert-danger" role="alert">
          {errors.onSave}
        </div>
      )}

      

      <TextInput
        name="first_name"
        label="First Name"
        value={employee.first_name}
        onChange={onChange}
        error={errors.first_name}
      />

      <TextInput
        name="last_name"
        label="Last Name"
        value={employee.last_name}
        onChange={onChange}
        error={errors.last_name}
      />

      <TextInput
        name="email"
        label="Email"
        value={employee.email}
        onChange={onChange}
        error={errors.email}
      />

    <SelectInput
        name="gender"
        label="Gender"
        value={employee.gender || ""}
        defaultOption={employee.gender || "Select gender"}
        options={[{
          value: "MALE",
          text: "Male"
        },{
          value: "FEMALE",
          text: "Female"
        },
        {
          value: "OTHER",
          text: "Other"
        }
      ]}
        onChange={onChange}
        error={errors.gender}
      />

      <SelectInput
        name="status"
        label="status"
        value={employee.status}
        defaultOption={(employee.status ? true : false) || "Select status"}
        options={[{
          value: true,
          text: "Active"
        },{
          value: false,
          text: "Inactive"
        }
      ]}
        onChange={onChange}
        error={errors.status}
      />

      <button type="submit" disabled={saving} className="btn btn-primary">
        {saving ? "Saving..." : "Save"}
      </button>
    </form>
  );
};

EmployeeForm.propTypes = {
  employee: PropTypes.object.isRequired,
  errors: PropTypes.object,
  onSave: PropTypes.func.isRequired,
  onChange: PropTypes.func.isRequired,
  saving: PropTypes.bool
};

export default EmployeeForm;
