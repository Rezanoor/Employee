import React from "react";
import { cleanup, render } from "react-testing-library";
import EmployeeForm from "./EmployeeForm";

afterEach(cleanup);

function renderEmployeeForm(args) {
  let defaultProps = {
    employee: {},
    saving: false,
    errors: {},
    onSave: () => {},
    onChange: () => {}
  };

  const props = { ...defaultProps, ...args };
  return render(<EmployeeForm {...props} />);
}

it("should render Add Employee header", () => {
  const { getByText } = renderEmployeeForm();
  getByText("Add Employee");
});

it('should label save button as "Save" when not saving', () => {
  const { getByText } = renderEmployeeForm();
  getByText("Save");
});

it('should label save button as "Saving..." when saving', () => {
  const { getByText, debug } = renderEmployeeForm({ saving: true });
  debug();
  getByText("Saving...");
});
