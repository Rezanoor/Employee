import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { loadEmployees, saveEmployee } from "../../redux/actions/employeeActions";
import PropTypes from "prop-types";
import EmployeeForm from "./EmployeeForm";
import { newEmployee } from "../../../tools/mockData";
import Spinner from "../common/Spinner";
import { toast } from "react-toastify";

export function ManageEmployeePage({
  employees,
  loadEmployees,
  saveEmployee,
  history,
  ...props
}) {
  const [employee, setEmployee] = useState({ ...props.employee });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (employees.length === 0) {
      loadEmployees().catch(error => {
        alert("Loading employees failed" + error);
      });
    } else {
      setEmployee({ ...props.employee });
    }

  }, [props.employee]);

  function handleChange(event) {
    const { name, value } = event.target;
    setEmployee(prevEmployee => ({
      ...prevEmployee,
      [name]:  value
    }));
  }

  function formIsValid() {
    const { first_name, last_name, email, gender } = employee;
    const errors = {};

    if (!first_name) errors.first_name = "First Name is required";
    if (!last_name) errors.last_name = "Last Name is required";
    if (!email) errors.email = "email is required";
    if (!gender) errors.gender = "gender is required";

    setErrors(errors);
    // Form is valid if the errors object still has no properties
    return Object.keys(errors).length === 0;
  }

  function handleSave(event) {
    event.preventDefault();
    if (!formIsValid()) return;
    setSaving(true);
    prepEmployee(employee)
    saveEmployee(employee)
      .then(() => {
        toast.success("Employee saved.");
        history.push("/employees");
      })
      .catch(error => {
        setSaving(false);
        setErrors({ onSave: error.message });
      });
  }

  function prepEmployee(employee) {
    employee.id = Number(employee.id); 
    employee.status = employee.status == "true" ? true : false;
  }

  return  employees.length === 0 ? (
    <Spinner />
  ) : (
    <EmployeeForm
      employee={employee}
      errors={errors}
      onChange={handleChange}
      onSave={handleSave}
      saving={saving}
    />
  );
}

ManageEmployeePage.propTypes = {
  employee: PropTypes.object.isRequired,
  employees: PropTypes.array.isRequired,
  loadEmployees: PropTypes.func.isRequired,
  saveEmployee: PropTypes.func.isRequired,
  history: PropTypes.object.isRequired
};

export function getEmployeeBySlug(employees, id) {
  return employees.find(employee => employee.id === Number(id)) || null;
}

function mapStateToProps(state, ownProps) {
  const id = ownProps.match.params.id;
  const employee =
    id && state.employees.length > 0
      ? getEmployeeBySlug(state.employees, id)
      : newEmployee;
  return {
    employee,
    employees: state.employees
  };
}

const mapDispatchToProps = {
  loadEmployees,
  saveEmployee
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ManageEmployeePage);
