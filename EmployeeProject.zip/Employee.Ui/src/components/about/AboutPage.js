import React from "react";

const AboutPage = () => (
  <div>
    <h2>About</h2>
    <p>
      This is a sample app for Standard Australia.
    </p>
  </div>
);

export default AboutPage;
