const employees = [
  {"id":13,"first_name":"Henka","last_name":"Beasleigh","email":"hbeasleighc@stumbleupon.com","gender":"Female","status":false},
  {"id":14,"first_name":"Kris","last_name":"Steanyng","email":"ksteanyngd@aboutads.info","gender":"Female","status":false},
  {"id":15,"first_name":"Lothario","last_name":"Tarte","email":"ltartee@163.com","gender":"Male","status":false},
  {"id":16,"first_name":"Barnabe","last_name":"Absolon","email":"babsolonf@geocities.com","gender":"Male","status":true}
];



const newEmployee = {
  id: null,
  first_name: "",
  last_name: "",
  email: "",
  gender: "",
  status: ""
};

// Using CommonJS style export so we can consume via Node (without using Babel-node)
module.exports = {
  newEmployee,
  employees
  
};
